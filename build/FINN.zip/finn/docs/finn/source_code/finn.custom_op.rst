*********
Custom Op
*********

Submodules
==========

.. toctree::
   :maxdepth: 2

   finn.custom_op.fpgadataflow
   qonnx.custom_op.general

Custom Op Nodes
===============

Base Class
----------

.. automodule:: qonnx.custom_op.base
   :members:
   :undoc-members:
   :show-inheritance:

qonnx.custom\_op.registry
-------------------------

.. automodule:: qonnx.custom_op.registry
  :members:
  :undoc-members:
  :show-inheritance:
