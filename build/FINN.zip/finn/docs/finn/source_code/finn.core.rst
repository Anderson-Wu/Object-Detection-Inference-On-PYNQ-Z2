****
Core
****

Modules
=======

qonnx.core.data\_layout
-------------------------

.. automodule:: qonnx.core.data_layout
   :members:
   :undoc-members:
   :show-inheritance:

qonnx.core.datatype
-------------------------

.. automodule:: qonnx.core.datatype
   :members:
   :undoc-members:
   :show-inheritance:

qonnx.core.execute\_custom\_node
--------------------------------------

.. automodule:: qonnx.core.execute_custom_node
   :members:
   :undoc-members:
   :show-inheritance:

qonnx.core.modelwrapper
-----------------------------

.. automodule:: qonnx.core.modelwrapper
   :members:
   :undoc-members:
   :show-inheritance:

finn.core.onnx\_exec
---------------------------

.. automodule:: finn.core.onnx_exec
   :members:
   :undoc-members:
   :show-inheritance:

finn.core.remote\_exec
-----------------------------

.. automodule:: finn.core.remote_exec
   :members:
   :undoc-members:
   :show-inheritance:

finn.core.rtlsim\_exec
-----------------------------

.. automodule:: finn.core.rtlsim_exec
   :members:
   :undoc-members:
   :show-inheritance:

finn.core.throughput\_test
---------------------------------

.. automodule:: finn.core.throughput_test
   :members:
   :undoc-members:
   :show-inheritance:
